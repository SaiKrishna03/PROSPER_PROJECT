#ifndef QUICKSORT_H
#define QUICKSORT_H

void quickSort(int[],int,int);

int partition(int[], int,int);

void quick_first(int [], int , int );

int partition_first(int [], int , int );

void quick_middle(int [], int, int);

void quick_random(int [],int,int,int);

#endif
