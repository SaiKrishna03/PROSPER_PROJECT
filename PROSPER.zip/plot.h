#ifndef PLOT_H
#define PLOT_H

void insertionsort_variants();

void quicksort_variants();

void hybridsort_variants();

//void variant_linear();

#endif
