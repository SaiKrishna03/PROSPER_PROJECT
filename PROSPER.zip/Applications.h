#ifndef APPLICATIONS_H
#define APPLICATIONS_H

void hanoi();

void lshaped_triomino();

void monkey_steps();

int circus();

#endif
