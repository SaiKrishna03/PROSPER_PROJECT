#ifndef QUICKSORT_INSERTION_H
#define QUICKSORT_INSERTION_H

void quick(int [],int,int);

void quickinsert(int [],int,int,int);

void merge(int [],int ,int ,int );

void mergesort_insertion(int [],int ,int ,int);

int variant_lin(int [],int,int);

void linear(int [],int,int);

#endif
