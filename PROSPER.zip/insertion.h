#ifndef INSERTION_H
#define INSERTION_H

	void iterative_insertion(int[],int);
	void recursive_insertion(int[],int,int,int);
	void bin_insertion(int[],int);
	int counting_inversion(int[],int);

#endif
